export default {
    COLOR: {
        mainColorLocal: '#1bc744',
        secondColorLocal: '#2d60f3',
        title: '#232628',
        red: '#f4385b',
        gray88: '#888888',
        grayAC: '#acacac',
        bg: '#edf1f3',
        dark: '#393c3e',
        white: '#ffffff',
        grayBlue: '#3e6477',
        hr: '#e1e1e2'
    },
}